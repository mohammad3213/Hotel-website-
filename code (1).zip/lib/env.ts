// Environment variables configuration
export const env = {
  MONGODB_URI:
    process.env.MONGODB_URI || "mongodb+srv://xgxhxgvxvx_db_user:i5y07uNTSc37Wndx@cluster0.21i8ahm.mongodb.net/",
}
