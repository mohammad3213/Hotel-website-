// Authentication and user management utilities
export interface User {
  id: string
  email: string
  password: string
  fullName: string
  createdAt: string
}

export interface Booking {
  id: string
  userId: string
  hotelId: string
  hotelName: string
  checkInDate: string
  checkOutDate: string
  guests: number
  roomType: string
  totalPrice: number
  status: "confirmed" | "cancelled"
  createdAt: string
}

const USERS_KEY = "elite_stays_users"
const BOOKINGS_KEY = "elite_stays_bookings"
const CURRENT_USER_KEY = "elite_stays_current_user"

// User Management
export const registerUser = (email: string, password: string, fullName: string): User | null => {
  const users = getAllUsers()

  if (users.some((u) => u.email === email)) {
    return null // Email already exists
  }

  const newUser: User = {
    id: `user_${Date.now()}`,
    email,
    password, // In production, this should be hashed
    fullName,
    createdAt: new Date().toISOString(),
  }

  users.push(newUser)
  localStorage.setItem(USERS_KEY, JSON.stringify(users))

  return newUser
}

export const loginUser = (email: string, password: string): User | null => {
  const users = getAllUsers()
  const user = users.find((u) => u.email === email && u.password === password)

  if (user) {
    localStorage.setItem(CURRENT_USER_KEY, JSON.stringify(user))
    return user
  }

  return null
}

export const logoutUser = () => {
  localStorage.removeItem(CURRENT_USER_KEY)
}

export const getCurrentUser = (): User | null => {
  const user = localStorage.getItem(CURRENT_USER_KEY)
  return user ? JSON.parse(user) : null
}

export const getAllUsers = (): User[] => {
  const users = localStorage.getItem(USERS_KEY)
  return users ? JSON.parse(users) : []
}

// Booking Management
export const createBooking = (
  userId: string,
  hotelId: string,
  hotelName: string,
  checkInDate: string,
  checkOutDate: string,
  guests: number,
  roomType: string,
  totalPrice: number,
): Booking => {
  const bookings = getAllBookings()

  const newBooking: Booking = {
    id: `booking_${Date.now()}`,
    userId,
    hotelId,
    hotelName,
    checkInDate,
    checkOutDate,
    guests,
    roomType,
    totalPrice,
    status: "confirmed",
    createdAt: new Date().toISOString(),
  }

  bookings.push(newBooking)
  localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings))

  return newBooking
}

export const getUserBookings = (userId: string): Booking[] => {
  const bookings = getAllBookings()
  return bookings.filter((b) => b.userId === userId)
}

export const getAllBookings = (): Booking[] => {
  const bookings = localStorage.getItem(BOOKINGS_KEY)
  return bookings ? JSON.parse(bookings) : []
}

export const cancelBooking = (bookingId: string): boolean => {
  const bookings = getAllBookings()
  const booking = bookings.find((b) => b.id === bookingId)

  if (booking) {
    booking.status = "cancelled"
    localStorage.setItem(BOOKINGS_KEY, JSON.stringify(bookings))
    return true
  }

  return false
}
