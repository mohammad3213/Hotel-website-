-- MongoDB Seed Data Script
-- Run this to populate your MongoDB database with initial hotel data

-- Note: This is a reference for the data structure
-- To actually seed MongoDB, use the MongoDB shell or a Node.js script

-- Hotels Collection
db.hotels.insertMany([
  {
    name: "Grand Plaza Hotel",
    description: "Luxury hotel in the heart of the city with stunning views and world-class amenities. Experience unparalleled comfort and service in our elegantly appointed rooms and suites.",
    address: "123 Main Street",
    city: "New York",
    country: "USA",
    pricePerNight: 299.99,
    imageUrl: "/luxury-hotel-lobby.png",
    amenities: ["WiFi", "Pool", "Spa", "Restaurant", "Gym", "Parking", "Room Service", "Concierge"],
    images: ["/luxury-hotel-lobby.png", "/grand-hotel-exterior.png"],
    createdAt: new Date()
  },
  {
    name: "Seaside Resort",
    description: "Beautiful beachfront resort perfect for a relaxing getaway. Enjoy pristine beaches, crystal-clear waters, and world-class dining.",
    address: "456 Ocean Drive",
    city: "Miami",
    country: "USA",
    pricePerNight: 249.99,
    imageUrl: "/tropical-beach-resort.png",
    amenities: ["WiFi", "Beach Access", "Pool", "Restaurant", "Bar", "Water Sports"],
    images: ["/tropical-beach-resort.png"],
    createdAt: new Date()
  },
  {
    name: "Mountain View Lodge",
    description: "Cozy mountain retreat with breathtaking views and outdoor activities. Perfect for nature lovers and adventure seekers.",
    address: "789 Mountain Road",
    city: "Denver",
    country: "USA",
    pricePerNight: 179.99,
    imageUrl: "/cozy-mountain-lodge.png",
    amenities: ["WiFi", "Fireplace", "Hiking Trails", "Restaurant", "Parking", "Ski Access"],
    images: ["/cozy-mountain-lodge.png"],
    createdAt: new Date()
  },
  {
    name: "City Center Inn",
    description: "Affordable and comfortable accommodation in the city center. Great location for business and leisure travelers.",
    address: "321 Downtown Ave",
    city: "Chicago",
    country: "USA",
    pricePerNight: 129.99,
    imageUrl: "/grand-hotel-exterior.png",
    amenities: ["WiFi", "Breakfast", "Parking"],
    images: ["/grand-hotel-exterior.png"],
    createdAt: new Date()
  }
]);

-- Note: After inserting hotels, get their _id values to use in reviews
-- Replace HOTEL_ID_1, HOTEL_ID_2, etc. with actual ObjectId values

-- Reviews Collection (sample data)
db.reviews.insertMany([
  {
    hotelId: "HOTEL_ID_1",
    guestName: "John Doe",
    guestEmail: "john@example.com",
    rating: 5,
    comment: "Amazing stay! The service was exceptional and the rooms were spotless.",
    date: "2025-01-15",
    createdAt: new Date()
  },
  {
    hotelId: "HOTEL_ID_1",
    guestName: "Sarah Johnson",
    guestEmail: "sarah@example.com",
    rating: 5,
    comment: "Absolutely loved it! The spa was incredible and the staff went above and beyond.",
    date: "2025-01-10",
    createdAt: new Date()
  }
]);
