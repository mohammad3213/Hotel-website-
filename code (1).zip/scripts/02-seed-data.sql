-- Insert sample hotels
INSERT INTO hotels (name, description, address, city, country, price_per_night, image_url, amenities, total_rooms) VALUES
('Grand Plaza Hotel', 'Luxury hotel in the heart of the city with stunning views and world-class amenities.', '123 Main Street', 'New York', 'USA', 299.99, '/placeholder.svg?height=400&width=600', ARRAY['WiFi', 'Pool', 'Spa', 'Gym', 'Restaurant', 'Bar', 'Parking'], 150),
('Seaside Resort', 'Beautiful beachfront resort perfect for a relaxing getaway with family.', '456 Ocean Drive', 'Miami', 'USA', 249.99, '/placeholder.svg?height=400&width=600', ARRAY['WiFi', 'Beach Access', 'Pool', 'Restaurant', 'Water Sports'], 200),
('Mountain View Lodge', 'Cozy mountain retreat with breathtaking views and outdoor activities.', '789 Alpine Road', 'Denver', 'USA', 179.99, '/placeholder.svg?height=400&width=600', ARRAY['WiFi', 'Fireplace', 'Hiking Trails', 'Restaurant', 'Parking'], 80),
('City Center Inn', 'Affordable and comfortable accommodation in the business district.', '321 Commerce Blvd', 'Chicago', 'USA', 129.99, '/placeholder.svg?height=400&width=600', ARRAY['WiFi', 'Business Center', 'Gym', 'Parking'], 120),
('Boutique Garden Hotel', 'Charming boutique hotel with beautiful gardens and personalized service.', '654 Garden Lane', 'San Francisco', 'USA', 219.99, '/placeholder.svg?height=400&width=600', ARRAY['WiFi', 'Garden', 'Restaurant', 'Spa', 'Parking'], 50);

-- Insert sample ratings
INSERT INTO ratings (hotel_id, guest_name, guest_email, rating, review) VALUES
(1, 'John Smith', 'john@example.com', 5, 'Absolutely amazing experience! The staff was incredibly friendly and the rooms were spotless.'),
(1, 'Sarah Johnson', 'sarah@example.com', 4, 'Great hotel with excellent amenities. Only minor issue was the breakfast timing.'),
(2, 'Michael Brown', 'michael@example.com', 5, 'Perfect beach vacation! The resort exceeded all our expectations.'),
(2, 'Emily Davis', 'emily@example.com', 5, 'Beautiful location and wonderful service. Will definitely come back!'),
(3, 'David Wilson', 'david@example.com', 4, 'Lovely mountain views and cozy atmosphere. Great for a winter getaway.'),
(4, 'Lisa Anderson', 'lisa@example.com', 4, 'Good value for money. Clean rooms and convenient location.'),
(5, 'Robert Taylor', 'robert@example.com', 5, 'The most charming hotel I have ever stayed at. Highly recommend!');
