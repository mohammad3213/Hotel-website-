// MongoDB Seed Script
// Run this with: node --loader ts-node/esm scripts/seed-mongodb.ts

import { MongoClient } from "mongodb"

const uri = process.env.MONGODB_URI || "mongodb+srv://xgxhxgvxvx_db_user:i5y07uNTSc37Wndx@cluster0.21i8ahm.mongodb.net/"

async function seedDatabase() {
  const client = new MongoClient(uri)

  try {
    await client.connect()
    console.log("Connected to MongoDB")

    const db = client.db("hotel_booking")

    // Clear existing data
    await db.collection("hotels").deleteMany({})
    await db.collection("reviews").deleteMany({})
    await db.collection("bookings").deleteMany({})
    console.log("Cleared existing data")

    // Insert hotels
    const hotelsResult = await db.collection("hotels").insertMany([
      {
        name: "Grand Plaza Hotel",
        description:
          "Luxury hotel in the heart of the city with stunning views and world-class amenities. Experience unparalleled comfort and service in our elegantly appointed rooms and suites.",
        address: "123 Main Street",
        city: "New York",
        country: "USA",
        pricePerNight: 299.99,
        imageUrl: "/luxury-hotel-lobby.png",
        amenities: ["WiFi", "Pool", "Spa", "Restaurant", "Gym", "Parking", "Room Service", "Concierge"],
        images: ["/luxury-hotel-lobby.png", "/grand-hotel-exterior.png"],
        createdAt: new Date(),
      },
      {
        name: "Seaside Resort",
        description:
          "Beautiful beachfront resort perfect for a relaxing getaway. Enjoy pristine beaches, crystal-clear waters, and world-class dining.",
        address: "456 Ocean Drive",
        city: "Miami",
        country: "USA",
        pricePerNight: 249.99,
        imageUrl: "/tropical-beach-resort.png",
        amenities: ["WiFi", "Beach Access", "Pool", "Restaurant", "Bar", "Water Sports"],
        images: ["/tropical-beach-resort.png"],
        createdAt: new Date(),
      },
      {
        name: "Mountain View Lodge",
        description:
          "Cozy mountain retreat with breathtaking views and outdoor activities. Perfect for nature lovers and adventure seekers.",
        address: "789 Mountain Road",
        city: "Denver",
        country: "USA",
        pricePerNight: 179.99,
        imageUrl: "/cozy-mountain-lodge.png",
        amenities: ["WiFi", "Fireplace", "Hiking Trails", "Restaurant", "Parking", "Ski Access"],
        images: ["/cozy-mountain-lodge.png"],
        createdAt: new Date(),
      },
      {
        name: "City Center Inn",
        description:
          "Affordable and comfortable accommodation in the city center. Great location for business and leisure travelers.",
        address: "321 Downtown Ave",
        city: "Chicago",
        country: "USA",
        pricePerNight: 129.99,
        imageUrl: "/grand-hotel-exterior.png",
        amenities: ["WiFi", "Breakfast", "Parking"],
        images: ["/grand-hotel-exterior.png"],
        createdAt: new Date(),
      },
    ])

    console.log(`Inserted ${Object.keys(hotelsResult.insertedIds).length} hotels`)

    // Get hotel IDs
    const hotelIds = Object.values(hotelsResult.insertedIds).map((id) => id.toString())

    // Insert sample reviews
    await db.collection("reviews").insertMany([
      {
        hotelId: hotelIds[0],
        guestName: "John Doe",
        guestEmail: "john@example.com",
        rating: 5,
        comment: "Amazing stay! The service was exceptional and the rooms were spotless.",
        date: "2025-01-15",
        createdAt: new Date(),
      },
      {
        hotelId: hotelIds[0],
        guestName: "Sarah Johnson",
        guestEmail: "sarah@example.com",
        rating: 5,
        comment: "Absolutely loved it! The spa was incredible and the staff went above and beyond.",
        date: "2025-01-10",
        createdAt: new Date(),
      },
      {
        hotelId: hotelIds[0],
        guestName: "Michael Chen",
        guestEmail: "michael@example.com",
        rating: 4,
        comment: "Great hotel with excellent amenities. The only downside was the breakfast could be better.",
        date: "2025-01-05",
        createdAt: new Date(),
      },
      {
        hotelId: hotelIds[1],
        guestName: "Jane Smith",
        guestEmail: "jane@example.com",
        rating: 4,
        comment: "Great location and friendly staff. Would definitely come back!",
        date: "2025-01-12",
        createdAt: new Date(),
      },
      {
        hotelId: hotelIds[1],
        guestName: "Robert Williams",
        guestEmail: "robert@example.com",
        rating: 5,
        comment: "Perfect beach vacation! The views were stunning and the food was delicious.",
        date: "2025-01-08",
        createdAt: new Date(),
      },
      {
        hotelId: hotelIds[2],
        guestName: "Mike Johnson",
        guestEmail: "mike@example.com",
        rating: 5,
        comment: "Perfect mountain getaway. The views were incredible!",
        date: "2025-01-14",
        createdAt: new Date(),
      },
      {
        hotelId: hotelIds[2],
        guestName: "Emily Davis",
        guestEmail: "emily@example.com",
        rating: 5,
        comment: "Cozy and charming! The fireplace in our room made it extra special.",
        date: "2025-01-09",
        createdAt: new Date(),
      },
      {
        hotelId: hotelIds[3],
        guestName: "David Brown",
        guestEmail: "david@example.com",
        rating: 4,
        comment: "Good value for money. Clean rooms and convenient location.",
        date: "2025-01-11",
        createdAt: new Date(),
      },
    ])

    console.log("Inserted sample reviews")
    console.log("Database seeded successfully!")
  } catch (error) {
    console.error("Error seeding database:", error)
  } finally {
    await client.close()
  }
}

seedDatabase()
