"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { MapPin, Star, Search, Sparkles } from "lucide-react"
import Link from "next/link"
import { AuthModal } from "@/components/auth-modal"
import { UserMenu } from "@/components/user-menu"
import { getCurrentUser } from "@/lib/auth"

type Hotel = {
  id: string
  name: string
  description: string
  address: string
  city: string
  country: string
  pricePerNight: number
  imageUrl: string
  amenities: string[]
  averageRating?: number
  reviewCount?: number
}

export default function Home() {
  const [searchQuery, setSearchQuery] = useState("")
  const [hotels, setHotels] = useState<Hotel[]>([])
  const [filteredHotels, setFilteredHotels] = useState<Hotel[]>([])
  const [loading, setLoading] = useState(true)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [currentUser, setCurrentUser] = useState(getCurrentUser())

  useEffect(() => {
    const fetchHotelsWithRatings = async () => {
      try {
        const hotelsRes = await fetch("/api/hotels")
        const hotelsData = await hotelsRes.json()

        // Fetch ratings for each hotel
        const hotelsWithRatings = await Promise.all(
          hotelsData.map(async (hotel: Hotel) => {
            try {
              const statsRes = await fetch(`/api/reviews/stats?hotelId=${hotel.id}`)
              const stats = await statsRes.json()
              return {
                ...hotel,
                averageRating: stats.averageRating || 0,
                reviewCount: stats.reviewCount || 0,
              }
            } catch (error) {
              console.error(`[v0] Error fetching stats for hotel ${hotel.id}:`, error)
              return { ...hotel, averageRating: 0, reviewCount: 0 }
            }
          }),
        )

        setHotels(hotelsWithRatings)
        setFilteredHotels(hotelsWithRatings)
      } catch (error) {
        console.error("[v0] Error fetching hotels:", error)
      } finally {
        setLoading(false)
      }
    }

    fetchHotelsWithRatings()
  }, [])

  const handleSearch = () => {
    if (!searchQuery.trim()) {
      setFilteredHotels(hotels)
      return
    }

    const filtered = hotels.filter(
      (hotel) =>
        hotel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hotel.city.toLowerCase().includes(searchQuery.toLowerCase()) ||
        hotel.country.toLowerCase().includes(searchQuery.toLowerCase()),
    )
    setFilteredHotels(filtered)
  }

  const handleBookClick = () => {
    if (!getCurrentUser()) {
      setShowAuthModal(true)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Sparkles className="h-12 w-12 text-amber-500 animate-pulse mx-auto" />
          <p className="text-amber-100 text-lg">Loading luxury experiences...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-amber-900/20 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="relative">
                <Sparkles className="h-7 w-7 text-amber-500" />
                <div className="absolute inset-0 blur-lg bg-amber-500/30" />
              </div>
              <h1 className="text-2xl font-serif font-bold bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 bg-clip-text text-transparent">
                Élite Stays
              </h1>
            </div>
            <div className="flex items-center gap-4">
              {currentUser ? (
                <>
                  <UserMenu onLogout={() => setCurrentUser(null)} />
                  <Button
                    asChild
                    variant="outline"
                    className="border-amber-700/50 text-amber-100 hover:bg-amber-950/50 hover:text-amber-50 bg-transparent"
                  >
                    <Link href="/admin">Admin Portal</Link>
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="outline"
                    onClick={() => setShowAuthModal(true)}
                    className="border-amber-700/50 text-amber-100 hover:bg-amber-950/50"
                  >
                    Sign In
                  </Button>
                  <Button
                    asChild
                    variant="outline"
                    className="border-amber-700/50 text-amber-100 hover:bg-amber-950/50 hover:text-amber-50 bg-transparent"
                  >
                    <Link href="/admin">Admin Portal</Link>
                  </Button>
                </>
              )}
            </div>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-amber-950/40 via-slate-900/60 to-slate-950/40 text-white py-32 overflow-hidden">
        <div className="absolute inset-0 bg-[url('/luxury-hotel-interior.png')] bg-cover bg-center opacity-10" />
        <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent" />
        <div className="container mx-auto px-4 relative z-10">
          <div className="max-w-4xl mx-auto text-center space-y-8">
            <div className="space-y-4">
              <p className="text-amber-400 text-sm font-medium tracking-[0.3em] uppercase">Curated Luxury</p>
              <h2 className="text-5xl md:text-7xl font-serif font-bold text-balance leading-tight">
                Discover Extraordinary
                <span className="block bg-gradient-to-r from-amber-200 via-amber-400 to-amber-200 bg-clip-text text-transparent">
                  Destinations
                </span>
              </h2>
            </div>
            <p className="text-xl text-slate-300 text-pretty max-w-2xl mx-auto leading-relaxed">
              Experience the world's most exclusive hotels and resorts, handpicked for the discerning traveler
            </p>

            {/* Search Bar */}
            <div className="flex gap-3 max-w-2xl mx-auto pt-4">
              <div className="relative flex-1">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-amber-600" />
                <Input
                  placeholder="Search destinations, hotels, experiences..."
                  className="pl-12 h-14 bg-slate-900/50 border-amber-900/30 text-white placeholder:text-slate-500 focus:border-amber-700/50 backdrop-blur-sm"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                />
              </div>
              <Button
                size="lg"
                onClick={handleSearch}
                className="bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white px-8 h-14 shadow-lg shadow-amber-900/30"
              >
                Explore
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* Hotels Grid */}
      <section className="container mx-auto px-4 py-20">
        <div className="mb-12">
          <h3 className="text-3xl font-serif font-bold text-amber-100 mb-3">
            {searchQuery ? `Curated Results (${filteredHotels.length})` : "Featured Collections"}
          </h3>
          <p className="text-slate-400 text-lg">
            {searchQuery
              ? `Showing results for "${searchQuery}"`
              : "Immerse yourself in unparalleled luxury and sophistication"}
          </p>
        </div>

        {filteredHotels.length === 0 ? (
          <Card className="p-16 text-center bg-slate-900/50 border-amber-900/20 backdrop-blur-sm">
            <p className="text-slate-400 text-lg">No properties found. Please refine your search.</p>
          </Card>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredHotels.map((hotel) => (
              <Card
                key={hotel.id}
                className="overflow-hidden bg-slate-900/50 border-amber-900/20 backdrop-blur-sm hover:shadow-2xl hover:shadow-amber-900/20 transition-all duration-500 hover:scale-[1.02] group"
              >
                <div className="relative h-64 overflow-hidden">
                  <img
                    src={hotel.imageUrl || "/placeholder.svg"}
                    alt={hotel.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950 via-transparent to-transparent opacity-60" />
                  <div className="absolute top-4 right-4 bg-slate-950/80 backdrop-blur-md px-4 py-2 rounded-full border border-amber-700/30">
                    {hotel.reviewCount && hotel.reviewCount > 0 ? (
                      <div className="flex items-center gap-2">
                        <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                        <span className="font-semibold text-sm text-amber-100">{hotel.averageRating?.toFixed(1)}</span>
                        <span className="text-xs text-slate-400">({hotel.reviewCount})</span>
                      </div>
                    ) : (
                      <span className="text-xs text-amber-400 font-medium">New</span>
                    )}
                  </div>
                </div>
                <CardHeader className="space-y-3">
                  <CardTitle className="text-2xl font-serif text-amber-100">{hotel.name}</CardTitle>
                  <CardDescription className="flex items-center gap-2 text-slate-400">
                    <MapPin className="h-4 w-4 text-amber-600" />
                    {hotel.city}, {hotel.country}
                  </CardDescription>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-sm text-slate-400 line-clamp-2 leading-relaxed">{hotel.description}</p>
                  <div className="flex flex-wrap gap-2">
                    {hotel.amenities.slice(0, 4).map((amenity, i) => (
                      <Badge
                        key={i}
                        variant="secondary"
                        className="text-xs bg-amber-950/30 text-amber-200 border-amber-800/30"
                      >
                        {amenity}
                      </Badge>
                    ))}
                    {hotel.amenities.length > 4 && (
                      <Badge variant="outline" className="text-xs border-amber-800/30 text-amber-300">
                        +{hotel.amenities.length - 4} more
                      </Badge>
                    )}
                  </div>
                </CardContent>
                <CardFooter className="flex items-center justify-between border-t border-amber-900/20 pt-6">
                  <div>
                    <p className="text-3xl font-serif font-bold text-amber-400">${hotel.pricePerNight}</p>
                    <p className="text-xs text-slate-500">per night</p>
                  </div>
                  <Button
                    onClick={handleBookClick}
                    className="bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white shadow-lg shadow-amber-900/30"
                  >
                    {currentUser ? "Book Now" : "Sign In to Book"}
                  </Button>
                </CardFooter>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* Footer */}
      <footer className="bg-slate-950 border-t border-amber-900/20 text-white py-12 mt-20">
        <div className="container mx-auto px-4 text-center space-y-4">
          <div className="flex items-center justify-center gap-2">
            <Sparkles className="h-5 w-5 text-amber-500" />
            <p className="font-serif text-lg text-amber-100">Élite Stays</p>
          </div>
          <p className="text-slate-500 text-sm">© 2025 Élite Stays. Crafted for the discerning traveler.</p>
        </div>
      </footer>

      {showAuthModal && (
        <AuthModal
          onSuccess={() => {
            setShowAuthModal(false)
            setCurrentUser(getCurrentUser())
          }}
        />
      )}
    </div>
  )
}
