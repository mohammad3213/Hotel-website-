"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Plus, Pencil, Trash2, Star, Shield } from "lucide-react"

type Hotel = {
  id: string
  name: string
  description: string
  address: string
  city: string
  country: string
  pricePerNight: number
  imageUrl: string
  amenities: string[]
  averageRating?: number
  reviewCount?: number
}

export default function AdminDashboard() {
  const [hotels, setHotels] = useState<Hotel[]>([])
  const [loading, setLoading] = useState(true)
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [editingHotel, setEditingHotel] = useState<Hotel | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    address: "",
    city: "",
    country: "",
    pricePerNight: "",
    imageUrl: "",
    amenities: "",
  })

  useEffect(() => {
    fetchHotels()
  }, [])

  const fetchHotels = async () => {
    try {
      const hotelsRes = await fetch("/api/hotels")
      const hotelsData = await hotelsRes.json()

      // Fetch ratings for each hotel
      const hotelsWithRatings = await Promise.all(
        hotelsData.map(async (hotel: Hotel) => {
          try {
            const statsRes = await fetch(`/api/reviews/stats?hotelId=${hotel.id}`)
            const stats = await statsRes.json()
            return {
              ...hotel,
              averageRating: stats.averageRating || 0,
              reviewCount: stats.reviewCount || 0,
            }
          } catch (error) {
            return { ...hotel, averageRating: 0, reviewCount: 0 }
          }
        }),
      )

      setHotels(hotelsWithRatings)
    } catch (error) {
      console.error("[v0] Error fetching hotels:", error)
    } finally {
      setLoading(false)
    }
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    const hotelData = {
      id: editingHotel?.id,
      name: formData.name,
      description: formData.description,
      address: formData.address,
      city: formData.city,
      country: formData.country,
      pricePerNight: Number.parseFloat(formData.pricePerNight),
      imageUrl: formData.imageUrl || "/grand-hotel-exterior.png",
      amenities: formData.amenities
        .split(",")
        .map((a) => a.trim())
        .filter(Boolean),
      images: [formData.imageUrl || "/grand-hotel-exterior.png"],
    }

    try {
      if (editingHotel) {
        await fetch("/api/hotels", {
          method: "PUT",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(hotelData),
        })
      } else {
        await fetch("/api/hotels", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(hotelData),
        })
      }

      await fetchHotels()
      resetForm()
      setIsDialogOpen(false)
    } catch (error) {
      console.error("[v0] Error saving hotel:", error)
    }
  }

  const handleEdit = (hotel: Hotel) => {
    setEditingHotel(hotel)
    setFormData({
      name: hotel.name,
      description: hotel.description,
      address: hotel.address,
      city: hotel.city,
      country: hotel.country,
      pricePerNight: hotel.pricePerNight.toString(),
      imageUrl: hotel.imageUrl,
      amenities: hotel.amenities.join(", "),
    })
    setIsDialogOpen(true)
  }

  const handleDelete = async (id: string) => {
    if (confirm("Are you sure you want to delete this hotel?")) {
      try {
        await fetch(`/api/hotels?id=${id}`, {
          method: "DELETE",
        })
        await fetchHotels()
      } catch (error) {
        console.error("[v0] Error deleting hotel:", error)
      }
    }
  }

  const resetForm = () => {
    setFormData({
      name: "",
      description: "",
      address: "",
      city: "",
      country: "",
      pricePerNight: "",
      imageUrl: "",
      amenities: "",
    })
    setEditingHotel(null)
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Shield className="h-12 w-12 text-amber-500 animate-pulse mx-auto" />
          <p className="text-amber-100 text-lg">Loading admin portal...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      <header className="border-b border-amber-900/20 bg-slate-950/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 py-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield className="h-7 w-7 text-amber-500" />
              <h1 className="text-2xl font-serif font-bold text-amber-100">Admin Portal</h1>
            </div>
            <Button
              asChild
              variant="outline"
              className="border-amber-700/50 text-amber-100 hover:bg-amber-950/50 bg-transparent"
            >
              <a href="/">View Public Site</a>
            </Button>
          </div>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <Card className="bg-slate-900/50 border-amber-900/20 backdrop-blur-sm">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-2xl font-serif text-amber-100">Property Management</CardTitle>
                <CardDescription className="text-slate-400">
                  Curate and manage your luxury hotel collection
                </CardDescription>
              </div>
              <Dialog
                open={isDialogOpen}
                onOpenChange={(open) => {
                  setIsDialogOpen(open)
                  if (!open) resetForm()
                }}
              >
                <DialogTrigger asChild>
                  <Button className="gap-2 bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600">
                    <Plus className="h-4 w-4" />
                    Add Property
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto bg-slate-900 border-amber-900/30">
                  <DialogHeader>
                    <DialogTitle className="text-amber-100">
                      {editingHotel ? "Edit Property" : "Add New Property"}
                    </DialogTitle>
                    <DialogDescription className="text-slate-400">
                      {editingHotel ? "Update property information" : "Enter the details for the new property"}
                    </DialogDescription>
                  </DialogHeader>
                  <form onSubmit={handleSubmit} className="space-y-4">
                    <div className="space-y-2">
                      <Label htmlFor="name" className="text-slate-300">
                        Hotel Name *
                      </Label>
                      <Input
                        id="name"
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        required
                        className="bg-slate-950/50 border-amber-900/30 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="description" className="text-slate-300">
                        Description *
                      </Label>
                      <Textarea
                        id="description"
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        required
                        rows={3}
                        className="bg-slate-950/50 border-amber-900/30 text-white"
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="address" className="text-slate-300">
                          Address *
                        </Label>
                        <Input
                          id="address"
                          value={formData.address}
                          onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                          required
                          className="bg-slate-950/50 border-amber-900/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="city" className="text-slate-300">
                          City *
                        </Label>
                        <Input
                          id="city"
                          value={formData.city}
                          onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                          required
                          className="bg-slate-950/50 border-amber-900/30 text-white"
                        />
                      </div>
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div className="space-y-2">
                        <Label htmlFor="country" className="text-slate-300">
                          Country *
                        </Label>
                        <Input
                          id="country"
                          value={formData.country}
                          onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                          required
                          className="bg-slate-950/50 border-amber-900/30 text-white"
                        />
                      </div>
                      <div className="space-y-2">
                        <Label htmlFor="price" className="text-slate-300">
                          Price per Night ($) *
                        </Label>
                        <Input
                          id="price"
                          type="number"
                          step="0.01"
                          value={formData.pricePerNight}
                          onChange={(e) => setFormData({ ...formData, pricePerNight: e.target.value })}
                          required
                          className="bg-slate-950/50 border-amber-900/30 text-white"
                        />
                      </div>
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="imageUrl" className="text-slate-300">
                        Image URL
                      </Label>
                      <Input
                        id="imageUrl"
                        type="url"
                        value={formData.imageUrl}
                        onChange={(e) => setFormData({ ...formData, imageUrl: e.target.value })}
                        placeholder="/placeholder.svg?height=400&width=600"
                        className="bg-slate-950/50 border-amber-900/30 text-white"
                      />
                    </div>
                    <div className="space-y-2">
                      <Label htmlFor="amenities" className="text-slate-300">
                        Amenities (comma-separated) *
                      </Label>
                      <Input
                        id="amenities"
                        value={formData.amenities}
                        onChange={(e) => setFormData({ ...formData, amenities: e.target.value })}
                        placeholder="WiFi, Pool, Spa, Restaurant"
                        required
                        className="bg-slate-950/50 border-amber-900/30 text-white"
                      />
                    </div>
                    <div className="flex justify-end gap-2">
                      <Button
                        type="button"
                        variant="outline"
                        onClick={() => setIsDialogOpen(false)}
                        className="border-amber-700/50 text-amber-100 hover:bg-amber-950/50"
                      >
                        Cancel
                      </Button>
                      <Button
                        type="submit"
                        className="bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600"
                      >
                        {editingHotel ? "Update Property" : "Add Property"}
                      </Button>
                    </div>
                  </form>
                </DialogContent>
              </Dialog>
            </div>
          </CardHeader>
          <CardContent>
            <div className="rounded-lg border border-amber-900/20 overflow-hidden">
              <Table>
                <TableHeader>
                  <TableRow className="border-amber-900/20 hover:bg-amber-950/20">
                    <TableHead className="text-amber-200">Name</TableHead>
                    <TableHead className="text-amber-200">Location</TableHead>
                    <TableHead className="text-amber-200">Price/Night</TableHead>
                    <TableHead className="text-amber-200">Rating</TableHead>
                    <TableHead className="text-amber-200">Amenities</TableHead>
                    <TableHead className="text-right text-amber-200">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {hotels.length === 0 ? (
                    <TableRow className="border-amber-900/20">
                      <TableCell colSpan={6} className="text-center text-slate-500 py-12">
                        No properties added yet. Click "Add Property" to get started.
                      </TableCell>
                    </TableRow>
                  ) : (
                    hotels.map((hotel) => (
                      <TableRow key={hotel.id} className="border-amber-900/20 hover:bg-amber-950/20">
                        <TableCell className="font-medium text-amber-100">{hotel.name}</TableCell>
                        <TableCell className="text-slate-300">
                          {hotel.city}, {hotel.country}
                        </TableCell>
                        <TableCell className="text-slate-300">${hotel.pricePerNight.toFixed(2)}</TableCell>
                        <TableCell>
                          {hotel.reviewCount && hotel.reviewCount > 0 ? (
                            <div className="flex items-center gap-1">
                              <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                              <span className="text-amber-100">{hotel.averageRating?.toFixed(1)}</span>
                              <span className="text-xs text-slate-500">({hotel.reviewCount})</span>
                            </div>
                          ) : (
                            <span className="text-slate-500">No ratings</span>
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex flex-wrap gap-1">
                            {hotel.amenities.slice(0, 3).map((amenity, i) => (
                              <span
                                key={i}
                                className="text-xs bg-amber-900/30 text-amber-200 px-2 py-1 rounded border border-amber-800/30"
                              >
                                {amenity}
                              </span>
                            ))}
                            {hotel.amenities.length > 3 && (
                              <span className="text-xs text-slate-500">+{hotel.amenities.length - 3}</span>
                            )}
                          </div>
                        </TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleEdit(hotel)}
                              className="hover:bg-amber-950/30 text-amber-100"
                            >
                              <Pencil className="h-4 w-4" />
                            </Button>
                            <Button
                              variant="ghost"
                              size="icon"
                              onClick={() => handleDelete(hotel.id)}
                              className="hover:bg-red-950/30 text-red-400"
                            >
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  )}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  )
}
