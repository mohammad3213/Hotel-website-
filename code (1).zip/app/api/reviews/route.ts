import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get("hotelId")
    const db = await getDatabase()

    const query = hotelId ? { hotelId } : {}
    const reviews = await db.collection("reviews").find(query).sort({ date: -1 }).toArray()

    const formattedReviews = reviews.map((review) => ({
      ...review,
      id: review._id.toString(),
      _id: undefined,
    }))

    return NextResponse.json(formattedReviews)
  } catch (error) {
    console.error("[v0] Error fetching reviews:", error)
    return NextResponse.json({ error: "Failed to fetch reviews" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const { hotelId, ...reviewData } = await request.json()
    const db = await getDatabase()

    const result = await db.collection("reviews").insertOne({
      hotelId,
      ...reviewData,
      date: new Date().toISOString().split("T")[0],
      createdAt: new Date(),
    })

    const newReview = {
      hotelId,
      ...reviewData,
      id: result.insertedId.toString(),
      date: new Date().toISOString().split("T")[0],
    }

    return NextResponse.json(newReview)
  } catch (error) {
    console.error("[v0] Error creating review:", error)
    return NextResponse.json({ error: "Failed to create review" }, { status: 500 })
  }
}
