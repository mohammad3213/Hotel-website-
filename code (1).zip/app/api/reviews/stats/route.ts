import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"

// In-memory storage for reviews (shared with reviews route)
const reviews: {
  [hotelId: string]: Array<{
    id: string
    guestName: string
    guestEmail: string
    rating: number
    comment: string
    date: string
  }>
} = {
  "1": [
    {
      id: "1",
      guestName: "John Doe",
      guestEmail: "john@example.com",
      rating: 5,
      comment: "Amazing stay! The service was exceptional and the rooms were spotless.",
      date: "2025-01-15",
    },
    {
      id: "2",
      guestName: "Sarah Johnson",
      guestEmail: "sarah@example.com",
      rating: 5,
      comment: "Absolutely loved it! The spa was incredible and the staff went above and beyond.",
      date: "2025-01-10",
    },
    {
      id: "3",
      guestName: "Michael Chen",
      guestEmail: "michael@example.com",
      rating: 4,
      comment: "Great hotel with excellent amenities. The only downside was the breakfast could be better.",
      date: "2025-01-05",
    },
  ],
  "2": [
    {
      id: "1",
      guestName: "Jane Smith",
      guestEmail: "jane@example.com",
      rating: 4,
      comment: "Great location and friendly staff. Would definitely come back!",
      date: "2025-01-12",
    },
    {
      id: "2",
      guestName: "Robert Williams",
      guestEmail: "robert@example.com",
      rating: 5,
      comment: "Perfect beach vacation! The views were stunning and the food was delicious.",
      date: "2025-01-08",
    },
  ],
  "3": [
    {
      id: "1",
      guestName: "Mike Johnson",
      guestEmail: "mike@example.com",
      rating: 5,
      comment: "Perfect mountain getaway. The views were incredible!",
      date: "2025-01-14",
    },
    {
      id: "2",
      guestName: "Emily Davis",
      guestEmail: "emily@example.com",
      rating: 5,
      comment: "Cozy and charming! The fireplace in our room made it extra special.",
      date: "2025-01-09",
    },
  ],
  "4": [
    {
      id: "1",
      guestName: "David Brown",
      guestEmail: "david@example.com",
      rating: 4,
      comment: "Good value for money. Clean rooms and convenient location.",
      date: "2025-01-11",
    },
  ],
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get("hotelId")

    if (!hotelId) {
      return NextResponse.json({ error: "Hotel ID required" }, { status: 400 })
    }

    const db = await getDatabase()
    const hotelReviews = await db.collection("reviews").find({ hotelId }).toArray()

    if (hotelReviews.length === 0) {
      return NextResponse.json({
        averageRating: 0,
        reviewCount: 0,
      })
    }

    const totalRating = hotelReviews.reduce((sum, review) => sum + review.rating, 0)
    const averageRating = totalRating / hotelReviews.length

    return NextResponse.json({
      averageRating: Math.round(averageRating * 10) / 10,
      reviewCount: hotelReviews.length,
    })
  } catch (error) {
    console.error("[v0] Error fetching review stats:", error)
    return NextResponse.json({ error: "Failed to fetch review stats" }, { status: 500 })
  }
}
