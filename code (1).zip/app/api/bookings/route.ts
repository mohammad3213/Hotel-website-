import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const hotelId = searchParams.get("hotelId")
    const db = await getDatabase()

    const query = hotelId ? { hotelId } : {}
    const bookings = await db.collection("bookings").find(query).toArray()

    const formattedBookings = bookings.map((booking) => ({
      ...booking,
      id: booking._id.toString(),
      _id: undefined,
    }))

    return NextResponse.json(formattedBookings)
  } catch (error) {
    console.error("[v0] Error fetching bookings:", error)
    return NextResponse.json({ error: "Failed to fetch bookings" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const booking = await request.json()
    const db = await getDatabase()

    const result = await db.collection("bookings").insertOne({
      ...booking,
      createdAt: new Date(),
    })

    const newBooking = {
      ...booking,
      id: result.insertedId.toString(),
      createdAt: new Date().toISOString(),
    }

    return NextResponse.json(newBooking)
  } catch (error) {
    console.error("[v0] Error creating booking:", error)
    return NextResponse.json({ error: "Failed to create booking" }, { status: 500 })
  }
}
