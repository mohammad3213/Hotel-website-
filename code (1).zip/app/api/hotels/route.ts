import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

export async function GET() {
  try {
    const db = await getDatabase()
    const hotels = await db.collection("hotels").find({}).toArray()

    // Convert MongoDB _id to id for frontend compatibility
    const formattedHotels = hotels.map((hotel) => ({
      ...hotel,
      id: hotel._id.toString(),
      _id: undefined,
    }))

    return NextResponse.json(formattedHotels)
  } catch (error) {
    console.error("[v0] Error fetching hotels:", error)
    return NextResponse.json({ error: "Failed to fetch hotels" }, { status: 500 })
  }
}

export async function POST(request: Request) {
  try {
    const hotel = await request.json()
    const db = await getDatabase()

    const result = await db.collection("hotels").insertOne({
      ...hotel,
      createdAt: new Date(),
    })

    const newHotel = {
      ...hotel,
      id: result.insertedId.toString(),
    }

    return NextResponse.json(newHotel)
  } catch (error) {
    console.error("[v0] Error creating hotel:", error)
    return NextResponse.json({ error: "Failed to create hotel" }, { status: 500 })
  }
}

export async function PUT(request: Request) {
  try {
    const updatedHotel = await request.json()
    const db = await getDatabase()

    const { id, ...hotelData } = updatedHotel

    await db
      .collection("hotels")
      .updateOne({ _id: new ObjectId(id) }, { $set: { ...hotelData, updatedAt: new Date() } })

    return NextResponse.json(updatedHotel)
  } catch (error) {
    console.error("[v0] Error updating hotel:", error)
    return NextResponse.json({ error: "Failed to update hotel" }, { status: 500 })
  }
}

export async function DELETE(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const id = searchParams.get("id")

    if (!id) {
      return NextResponse.json({ error: "Hotel ID required" }, { status: 400 })
    }

    const db = await getDatabase()
    await db.collection("hotels").deleteOne({ _id: new ObjectId(id) })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("[v0] Error deleting hotel:", error)
    return NextResponse.json({ error: "Failed to delete hotel" }, { status: 500 })
  }
}
