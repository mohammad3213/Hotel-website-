import { NextResponse } from "next/server"
import { getDatabase } from "@/lib/mongodb"
import { ObjectId } from "mongodb"

// In-memory storage (in production, use a real database)
const hotels = [
  {
    id: "1",
    name: "Grand Plaza Hotel",
    description:
      "Luxury hotel in the heart of the city with stunning views and world-class amenities. Experience unparalleled comfort and service in our elegantly appointed rooms and suites.",
    address: "123 Main Street",
    city: "New York",
    country: "USA",
    pricePerNight: 299.99,
    imageUrl: "/luxury-hotel-lobby.png",
    amenities: ["WiFi", "Pool", "Spa", "Restaurant", "Gym", "Parking", "Room Service", "Concierge"],
    images: ["/luxury-hotel-lobby.png", "/grand-hotel-exterior.png"],
  },
  {
    id: "2",
    name: "Seaside Resort",
    description:
      "Beautiful beachfront resort perfect for a relaxing getaway. Enjoy pristine beaches, crystal-clear waters, and world-class dining.",
    address: "456 Ocean Drive",
    city: "Miami",
    country: "USA",
    pricePerNight: 249.99,
    imageUrl: "/tropical-beach-resort.png",
    amenities: ["WiFi", "Beach Access", "Pool", "Restaurant", "Bar", "Water Sports"],
    images: ["/tropical-beach-resort.png"],
  },
  {
    id: "3",
    name: "Mountain View Lodge",
    description:
      "Cozy mountain retreat with breathtaking views and outdoor activities. Perfect for nature lovers and adventure seekers.",
    address: "789 Mountain Road",
    city: "Denver",
    country: "USA",
    pricePerNight: 179.99,
    imageUrl: "/cozy-mountain-lodge.png",
    amenities: ["WiFi", "Fireplace", "Hiking Trails", "Restaurant", "Parking", "Ski Access"],
    images: ["/cozy-mountain-lodge.png"],
  },
  {
    id: "4",
    name: "City Center Inn",
    description:
      "Affordable and comfortable accommodation in the city center. Great location for business and leisure travelers.",
    address: "321 Downtown Ave",
    city: "Chicago",
    country: "USA",
    pricePerNight: 129.99,
    imageUrl: "/grand-hotel-exterior.png",
    amenities: ["WiFi", "Breakfast", "Parking"],
    images: ["/grand-hotel-exterior.png"],
  },
]

export async function GET(request: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params
    const db = await getDatabase()

    const hotel = await db.collection("hotels").findOne({ _id: new ObjectId(id) })

    if (!hotel) {
      return NextResponse.json({ error: "Hotel not found" }, { status: 404 })
    }

    const formattedHotel = {
      ...hotel,
      id: hotel._id.toString(),
      _id: undefined,
    }

    return NextResponse.json(formattedHotel)
  } catch (error) {
    console.error("[v0] Error fetching hotel:", error)
    return NextResponse.json({ error: "Failed to fetch hotel" }, { status: 500 })
  }
}
