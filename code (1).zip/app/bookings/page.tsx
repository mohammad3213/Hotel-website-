"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Calendar, Users, MapPin, CreditCard, Sparkles, ArrowLeft, Trash2 } from "lucide-react"
import Link from "next/link"
import { getCurrentUser, getUserBookings, cancelBooking, type Booking } from "@/lib/auth"
import { useRouter } from "next/navigation"

export default function BookingsPage() {
  const router = useRouter()
  const [bookings, setBookings] = useState<Booking[]>([])
  const [loading, setLoading] = useState(true)
  const [user, setUser] = useState(getCurrentUser())

  useEffect(() => {
    const currentUser = getCurrentUser()
    if (!currentUser) {
      router.push("/")
      return
    }

    setUser(currentUser)
    const userBookings = getUserBookings(currentUser.id)
    setBookings(userBookings)
    setLoading(false)
  }, [router])

  const handleCancelBooking = (bookingId: string) => {
    if (confirm("Are you sure you want to cancel this booking?")) {
      cancelBooking(bookingId)
      setBookings(bookings.map((b) => (b.id === bookingId ? { ...b, status: "cancelled" } : b)))
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950 flex items-center justify-center">
        <div className="text-center space-y-4">
          <Sparkles className="h-12 w-12 text-amber-500 animate-pulse mx-auto" />
          <p className="text-amber-100 text-lg">Loading your bookings...</p>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-900 to-slate-950">
      {/* Header */}
      <header className="border-b border-amber-900/20 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-5">
          <Button variant="ghost" asChild className="text-amber-100 hover:text-amber-50 hover:bg-amber-950/30">
            <Link href="/" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Hotels
            </Link>
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="mb-12">
          <h1 className="text-4xl md:text-5xl font-serif font-bold text-amber-100 mb-3">My Bookings</h1>
          <p className="text-slate-400 text-lg">Welcome back, {user?.fullName}</p>
        </div>

        {bookings.length === 0 ? (
          <Card className="p-16 text-center bg-slate-900/50 border-amber-900/20 backdrop-blur-sm">
            <div className="space-y-4">
              <Calendar className="h-12 w-12 text-amber-600 mx-auto opacity-50" />
              <div>
                <p className="text-slate-300 text-lg font-semibold mb-2">No bookings yet</p>
                <p className="text-slate-500 mb-6">Start exploring and book your next luxury stay</p>
                <Button
                  asChild
                  className="bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600"
                >
                  <Link href="/">Browse Hotels</Link>
                </Button>
              </div>
            </div>
          </Card>
        ) : (
          <div className="space-y-6">
            {bookings.map((booking) => {
              const checkIn = new Date(booking.checkInDate)
              const checkOut = new Date(booking.checkOutDate)
              const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24))

              return (
                <Card
                  key={booking.id}
                  className={`overflow-hidden bg-slate-900/50 border-amber-900/20 backdrop-blur-sm transition-all ${
                    booking.status === "cancelled" ? "opacity-60" : ""
                  }`}
                >
                  <CardHeader className="pb-3">
                    <div className="flex items-start justify-between">
                      <div>
                        <CardTitle className="text-2xl font-serif text-amber-100 mb-2">{booking.hotelName}</CardTitle>
                        <CardDescription className="text-slate-400">Booking ID: {booking.id}</CardDescription>
                      </div>
                      <Badge
                        className={`${
                          booking.status === "confirmed"
                            ? "bg-green-950/30 text-green-200 border-green-800/30"
                            : "bg-red-950/30 text-red-200 border-red-800/30"
                        }`}
                      >
                        {booking.status.charAt(0).toUpperCase() + booking.status.slice(1)}
                      </Badge>
                    </div>
                  </CardHeader>
                  <CardContent className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                      <div className="flex items-center gap-3 p-3 bg-amber-950/20 rounded-lg border border-amber-900/30">
                        <Calendar className="h-5 w-5 text-amber-600" />
                        <div>
                          <p className="text-xs text-slate-500">Check-in</p>
                          <p className="font-semibold text-amber-100">{checkIn.toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 bg-amber-950/20 rounded-lg border border-amber-900/30">
                        <Calendar className="h-5 w-5 text-amber-600" />
                        <div>
                          <p className="text-xs text-slate-500">Check-out</p>
                          <p className="font-semibold text-amber-100">{checkOut.toLocaleDateString()}</p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 bg-amber-950/20 rounded-lg border border-amber-900/30">
                        <Users className="h-5 w-5 text-amber-600" />
                        <div>
                          <p className="text-xs text-slate-500">Guests</p>
                          <p className="font-semibold text-amber-100">
                            {booking.guests} {booking.guests === 1 ? "Guest" : "Guests"}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3 p-3 bg-amber-950/20 rounded-lg border border-amber-900/30">
                        <MapPin className="h-5 w-5 text-amber-600" />
                        <div>
                          <p className="text-xs text-slate-500">Room Type</p>
                          <p className="font-semibold text-amber-100 capitalize">{booking.roomType}</p>
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-4 bg-amber-950/30 rounded-lg border border-amber-900/30">
                      <div className="flex items-center gap-2">
                        <CreditCard className="h-5 w-5 text-amber-600" />
                        <span className="text-slate-400">Total Price ({nights} nights)</span>
                      </div>
                      <span className="text-2xl font-serif font-bold text-amber-400">
                        ${booking.totalPrice.toFixed(2)}
                      </span>
                    </div>

                    <div className="text-xs text-slate-500">
                      Booked on {new Date(booking.createdAt).toLocaleDateString()} at{" "}
                      {new Date(booking.createdAt).toLocaleTimeString()}
                    </div>

                    {booking.status === "confirmed" && (
                      <Button
                        variant="destructive"
                        onClick={() => handleCancelBooking(booking.id)}
                        className="w-full gap-2"
                      >
                        <Trash2 className="h-4 w-4" />
                        Cancel Booking
                      </Button>
                    )}
                  </CardContent>
                </Card>
              )
            })}
          </div>
        )}
      </main>
    </div>
  )
}
