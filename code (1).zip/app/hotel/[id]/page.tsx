"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Separator } from "@/components/ui/separator"
import { MapPin, Star, Check, ArrowLeft, Sparkles } from "lucide-react"
import Link from "next/link"
import { useParams } from "next/navigation"
import { BookingForm } from "@/components/booking-form"
import { AuthModal } from "@/components/auth-modal"
import { getCurrentUser } from "@/lib/auth"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"

type Hotel = {
  id: string
  name: string
  description: string
  address: string
  city: string
  country: string
  pricePerNight: number
  imageUrl: string
  amenities: string[]
  images: string[]
}

type Review = {
  id: string
  guestName: string
  rating: number
  comment: string
  date: string
}

export default function HotelDetailPage() {
  const params = useParams()
  const [hotel, setHotel] = useState<Hotel | null>(null)
  const [reviews, setReviews] = useState<Review[]>([])
  const [averageRating, setAverageRating] = useState(0)
  const [reviewCount, setReviewCount] = useState(0)
  const [loading, setLoading] = useState(true)
  const [showAuthModal, setShowAuthModal] = useState(false)
  const [currentUser, setCurrentUser] = useState(getCurrentUser())

  const [isRatingOpen, setIsRatingOpen] = useState(false)
  const [ratingSuccess, setRatingSuccess] = useState(false)
  const [ratingData, setRatingData] = useState({
    guestName: "",
    guestEmail: "",
    rating: 5,
    comment: "",
  })
  const [hoveredRating, setHoveredRating] = useState(0)

  const fetchHotelData = async () => {
    try {
      const [hotelRes, reviewsRes, statsRes] = await Promise.all([
        fetch(`/api/hotels/${params.id}`),
        fetch(`/api/reviews?hotelId=${params.id}`),
        fetch(`/api/reviews/stats?hotelId=${params.id}`),
      ])

      const hotelData = await hotelRes.json()
      const reviewsData = await reviewsRes.json()
      const statsData = await statsRes.json()

      setHotel(hotelData)
      setReviews(reviewsData)
      setAverageRating(statsData.averageRating)
      setReviewCount(statsData.reviewCount)
    } catch (error) {
      console.error("[v0] Error fetching hotel data:", error)
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchHotelData()
  }, [params.id])

  const handleRatingSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      const response = await fetch("/api/reviews", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          hotelId: params.id,
          ...ratingData,
        }),
      })

      if (response.ok) {
        await fetchHotelData()

        setRatingSuccess(true)
        setTimeout(() => {
          setIsRatingOpen(false)
          setRatingSuccess(false)
          setRatingData({
            guestName: "",
            guestEmail: "",
            rating: 5,
            comment: "",
          })
        }, 2000)
      }
    } catch (error) {
      console.error("[v0] Error submitting review:", error)
    }
  }

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-950 to-slate-950">
        <div className="text-center space-y-4">
          <Sparkles className="h-12 w-12 text-amber-500 animate-pulse mx-auto" />
          <p className="text-amber-100 text-lg">Loading property details...</p>
        </div>
      </div>
    )
  }

  if (!hotel) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-950 via-slate-950 to-slate-950">
        <Card className="p-12 bg-slate-900/50 border-amber-900/20 backdrop-blur-sm">
          <p className="text-lg text-slate-300 mb-6">Property not found</p>
          <Button
            asChild
            className="bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600"
          >
            <Link href="/">Return Home</Link>
          </Button>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-950 via-slate-950 to-slate-950">
      {/* Header */}
      <header className="border-b border-amber-900/20 bg-slate-950/80 backdrop-blur-xl sticky top-0 z-50">
        <div className="container mx-auto px-4 py-5">
          <Button variant="ghost" asChild className="text-amber-100 hover:text-amber-50 hover:bg-amber-950/30">
            <Link href="/" className="gap-2">
              <ArrowLeft className="h-4 w-4" />
              Back to Collection
            </Link>
          </Button>
        </div>
      </header>

      <main className="container mx-auto px-4 py-12">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-10">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-8">
            {/* Image Gallery */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {hotel.images.map((img, i) => (
                <div
                  key={i}
                  className="relative h-72 md:h-96 rounded-xl overflow-hidden border border-amber-900/20 group"
                >
                  <img
                    src={img || "/placeholder.svg"}
                    alt={`${hotel.name} - Image ${i + 1}`}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/60 via-transparent to-transparent" />
                </div>
              ))}
            </div>

            {/* Hotel Info */}
            <Card className="bg-slate-900/50 border-amber-900/20 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div className="space-y-3">
                    <CardTitle className="text-4xl font-serif text-amber-100">{hotel.name}</CardTitle>
                    <CardDescription className="flex items-center gap-2 text-base text-slate-400">
                      <MapPin className="h-5 w-5 text-amber-600" />
                      {hotel.address}, {hotel.city}, {hotel.country}
                    </CardDescription>
                  </div>
                  {reviewCount > 0 ? (
                    <div className="flex items-center gap-3 bg-amber-950/30 px-5 py-3 rounded-xl border border-amber-800/30">
                      <Star className="h-6 w-6 fill-amber-400 text-amber-400" />
                      <div>
                        <p className="font-bold text-xl text-amber-100">{averageRating.toFixed(1)}</p>
                        <p className="text-xs text-slate-500">{reviewCount} reviews</p>
                      </div>
                    </div>
                  ) : (
                    <div className="bg-amber-950/30 px-5 py-3 rounded-xl border border-amber-800/30">
                      <p className="text-sm text-amber-400">No reviews yet</p>
                    </div>
                  )}
                </div>
              </CardHeader>
              <CardContent className="space-y-8">
                <div>
                  <h3 className="font-serif font-semibold text-xl mb-3 text-amber-100">About this property</h3>
                  <p className="text-slate-400 leading-relaxed text-base">{hotel.description}</p>
                </div>

                <Separator className="bg-amber-900/20" />

                <div>
                  <h3 className="font-serif font-semibold text-xl mb-4 text-amber-100">Amenities & Services</h3>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                    {hotel.amenities.map((amenity, i) => (
                      <div key={i} className="flex items-center gap-3">
                        <Check className="h-5 w-5 text-amber-500" />
                        <span className="text-sm text-slate-300">{amenity}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Reviews Section */}
            <Card className="bg-slate-900/50 border-amber-900/20 backdrop-blur-sm">
              <CardHeader>
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="text-2xl font-serif text-amber-100">Guest Reviews</CardTitle>
                    <CardDescription className="text-slate-400">
                      {reviewCount} {reviewCount === 1 ? "review" : "reviews"}
                    </CardDescription>
                  </div>
                  <Dialog open={isRatingOpen} onOpenChange={setIsRatingOpen}>
                    <DialogTrigger asChild>
                      <Button
                        variant="outline"
                        className="gap-2 border-amber-700/50 text-amber-100 hover:bg-amber-950/50 bg-transparent"
                      >
                        <Star className="h-4 w-4" />
                        Write Review
                      </Button>
                    </DialogTrigger>
                    <DialogContent className="max-w-md bg-slate-900 border-amber-900/30">
                      <DialogHeader>
                        <DialogTitle className="text-amber-100">Share Your Experience</DialogTitle>
                        <DialogDescription className="text-slate-400">
                          Tell us about your stay at {hotel.name}
                        </DialogDescription>
                      </DialogHeader>

                      {ratingSuccess ? (
                        <div className="py-8 text-center space-y-4">
                          <div className="w-16 h-16 bg-amber-950/30 rounded-full flex items-center justify-center mx-auto border border-amber-700/30">
                            <Check className="h-8 w-8 text-amber-400" />
                          </div>
                          <div>
                            <h3 className="text-xl font-semibold text-amber-400">Review Submitted!</h3>
                            <p className="text-slate-400 mt-2">Thank you for your valuable feedback.</p>
                          </div>
                        </div>
                      ) : (
                        <form onSubmit={handleRatingSubmit} className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="reviewerName" className="text-slate-300">
                              Your Name *
                            </Label>
                            <Input
                              id="reviewerName"
                              value={ratingData.guestName}
                              onChange={(e) => setRatingData({ ...ratingData, guestName: e.target.value })}
                              required
                              className="bg-slate-950/50 border-amber-900/30 text-white"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="reviewerEmail" className="text-slate-300">
                              Email *
                            </Label>
                            <Input
                              id="reviewerEmail"
                              type="email"
                              value={ratingData.guestEmail}
                              onChange={(e) => setRatingData({ ...ratingData, guestEmail: e.target.value })}
                              required
                              className="bg-slate-950/50 border-amber-900/30 text-white"
                            />
                          </div>
                          <div className="space-y-2">
                            <Label className="text-slate-300">Rating *</Label>
                            <div className="flex gap-2">
                              {[1, 2, 3, 4, 5].map((star) => (
                                <button
                                  key={star}
                                  type="button"
                                  onClick={() => setRatingData({ ...ratingData, rating: star })}
                                  onMouseEnter={() => setHoveredRating(star)}
                                  onMouseLeave={() => setHoveredRating(0)}
                                  className="transition-transform hover:scale-110"
                                >
                                  <Star
                                    className={`h-8 w-8 ${
                                      star <= (hoveredRating || ratingData.rating)
                                        ? "fill-amber-400 text-amber-400"
                                        : "text-slate-600"
                                    }`}
                                  />
                                </button>
                              ))}
                            </div>
                          </div>
                          <div className="space-y-2">
                            <Label htmlFor="reviewComment" className="text-slate-300">
                              Your Review *
                            </Label>
                            <Textarea
                              id="reviewComment"
                              value={ratingData.comment}
                              onChange={(e) => setRatingData({ ...ratingData, comment: e.target.value })}
                              placeholder="Share your experience..."
                              rows={4}
                              required
                              className="bg-slate-950/50 border-amber-900/30 text-white"
                            />
                          </div>
                          <Button
                            type="submit"
                            className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600"
                            size="lg"
                          >
                            Submit Review
                          </Button>
                        </form>
                      )}
                    </DialogContent>
                  </Dialog>
                </div>
              </CardHeader>
              <CardContent className="space-y-6">
                {reviews.length === 0 ? (
                  <p className="text-slate-500 text-center py-8">
                    No reviews yet. Be the first to share your experience!
                  </p>
                ) : (
                  reviews.map((review) => (
                    <div key={review.id} className="border-b border-amber-900/20 last:border-0 pb-6 last:pb-0">
                      <div className="flex items-start justify-between mb-3">
                        <div>
                          <p className="font-semibold text-amber-100">{review.guestName}</p>
                          <p className="text-xs text-slate-500">{new Date(review.date).toLocaleDateString()}</p>
                        </div>
                        <div className="flex items-center gap-1">
                          {Array.from({ length: 5 }).map((_, i) => (
                            <Star
                              key={i}
                              className={`h-4 w-4 ${
                                i < review.rating ? "fill-amber-400 text-amber-400" : "text-slate-700"
                              }`}
                            />
                          ))}
                        </div>
                      </div>
                      <p className="text-slate-400 leading-relaxed">{review.comment}</p>
                    </div>
                  ))
                )}
              </CardContent>
            </Card>
          </div>

          <div className="lg:col-span-1">
            {currentUser ? (
              <BookingForm hotelId={hotel.id} hotelName={hotel.name} pricePerNight={hotel.pricePerNight} />
            ) : (
              <Card className="sticky top-24 bg-slate-900/50 border-amber-900/20 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-2xl font-serif text-amber-100">Reserve Your Stay</CardTitle>
                  <div className="flex items-baseline gap-2">
                    <span className="text-4xl font-serif font-bold text-amber-400">${hotel.pricePerNight}</span>
                    <span className="text-slate-500">per night</span>
                  </div>
                </CardHeader>
                <CardContent className="space-y-4">
                  <p className="text-slate-400 text-sm">Sign in to your account to book this property.</p>
                  <Button
                    onClick={() => setShowAuthModal(true)}
                    size="lg"
                    className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 shadow-lg shadow-amber-900/30"
                  >
                    Sign In to Book
                  </Button>
                </CardContent>
              </Card>
            )}
          </div>
        </div>
      </main>

      {/* Auth modal for non-authenticated users */}
      {showAuthModal && (
        <AuthModal
          onSuccess={() => {
            setShowAuthModal(false)
            setCurrentUser(getCurrentUser())
          }}
        />
      )}
    </div>
  )
}
