"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { registerUser, loginUser } from "@/lib/auth"
import { AlertCircle } from "lucide-react"

interface AuthModalProps {
  onSuccess: () => void
}

export function AuthModal({ onSuccess }: AuthModalProps) {
  const [isLogin, setIsLogin] = useState(true)
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [fullName, setFullName] = useState("")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      if (isLogin) {
        const user = loginUser(email, password)
        if (!user) {
          setError("Invalid email or password")
          setLoading(false)
          return
        }
      } else {
        if (!fullName.trim()) {
          setError("Full name is required")
          setLoading(false)
          return
        }

        const user = registerUser(email, password, fullName)
        if (!user) {
          setError("Email already registered")
          setLoading(false)
          return
        }
      }

      onSuccess()
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="fixed inset-0 bg-black/50 backdrop-blur-sm flex items-center justify-center z-50 p-4">
      <Card className="w-full max-w-md bg-slate-900 border-amber-900/20">
        <CardHeader>
          <CardTitle className="text-2xl text-amber-100 font-serif">
            {isLogin ? "Welcome Back" : "Create Account"}
          </CardTitle>
          <CardDescription className="text-slate-400">
            {isLogin ? "Sign in to your Elite Stays account" : "Join Elite Stays today"}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            {error && (
              <div className="flex gap-2 p-3 bg-red-950/30 border border-red-900/50 rounded-lg text-red-200 text-sm">
                <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
                <span>{error}</span>
              </div>
            )}

            {!isLogin && (
              <div className="space-y-1">
                <label className="text-sm text-amber-200">Full Name</label>
                <Input
                  type="text"
                  placeholder="John Doe"
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  className="bg-slate-800/50 border-amber-900/30 text-white placeholder:text-slate-500"
                />
              </div>
            )}

            <div className="space-y-1">
              <label className="text-sm text-amber-200">Email</label>
              <Input
                type="email"
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="bg-slate-800/50 border-amber-900/30 text-white placeholder:text-slate-500"
              />
            </div>

            <div className="space-y-1">
              <label className="text-sm text-amber-200">Password</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="bg-slate-800/50 border-amber-900/30 text-white placeholder:text-slate-500"
              />
            </div>

            <Button
              type="submit"
              disabled={loading}
              className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white"
            >
              {loading ? "Processing..." : isLogin ? "Sign In" : "Create Account"}
            </Button>

            <div className="relative">
              <div className="absolute inset-0 flex items-center">
                <div className="w-full border-t border-amber-900/20" />
              </div>
              <div className="relative flex justify-center text-sm">
                <span className="px-2 bg-slate-900 text-slate-500">or</span>
              </div>
            </div>

            <Button
              type="button"
              variant="outline"
              onClick={() => {
                setIsLogin(!isLogin)
                setError("")
              }}
              className="w-full border-amber-900/30 text-amber-200 hover:bg-amber-950/30"
            >
              {isLogin ? "Create New Account" : "Sign In Instead"}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
