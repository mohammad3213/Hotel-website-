"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { getCurrentUser, logoutUser } from "@/lib/auth"
import { LogOut, User, Bookmark } from "lucide-react"
import Link from "next/link"

interface UserMenuProps {
  onLogout?: () => void
}

export function UserMenu({ onLogout }: UserMenuProps) {
  const user = getCurrentUser()
  const [open, setOpen] = useState(false)

  if (!user) return null

  const handleLogout = () => {
    logoutUser()
    setOpen(false)
    onLogout?.()
  }

  return (
    <div className="relative">
      <Button
        variant="outline"
        size="sm"
        onClick={() => setOpen(!open)}
        className="border-amber-700/50 text-amber-100 hover:bg-amber-950/50"
      >
        <User className="h-4 w-4 mr-2" />
        {user.fullName}
      </Button>

      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-slate-900 border border-amber-900/30 rounded-lg shadow-lg z-50">
          <Link
            href="/bookings"
            className="flex items-center gap-2 px-4 py-2 hover:bg-amber-950/30 text-amber-100 text-sm border-b border-amber-900/20"
          >
            <Bookmark className="h-4 w-4" />
            My Bookings
          </Link>
          <button
            onClick={handleLogout}
            className="w-full text-left flex items-center gap-2 px-4 py-2 hover:bg-red-950/30 text-red-200 text-sm"
          >
            <LogOut className="h-4 w-4" />
            Sign Out
          </button>
        </div>
      )}
    </div>
  )
}
