"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { createBooking, getCurrentUser } from "@/lib/auth"
import { Calendar, Users, AlertCircle } from "lucide-react"

interface BookingFormProps {
  hotelId: string
  hotelName: string
  pricePerNight: number
  onBookingComplete?: () => void
}

export function BookingForm({ hotelId, hotelName, pricePerNight, onBookingComplete }: BookingFormProps) {
  const [checkInDate, setCheckInDate] = useState("")
  const [checkOutDate, setCheckOutDate] = useState("")
  const [guests, setGuests] = useState("1")
  const [roomType, setRoomType] = useState("standard")
  const [error, setError] = useState("")
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const calculateTotalPrice = (): number => {
    if (!checkInDate || !checkOutDate) return 0

    const checkIn = new Date(checkInDate)
    const checkOut = new Date(checkOutDate)
    const nights = Math.ceil((checkOut.getTime() - checkIn.getTime()) / (1000 * 60 * 60 * 24))

    if (nights <= 0) return 0

    const roomMultiplier = roomType === "deluxe" ? 1.5 : roomType === "suite" ? 2 : 1
    return nights * pricePerNight * roomMultiplier
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setLoading(true)

    try {
      const user = getCurrentUser()
      if (!user) {
        setError("Please log in to book a hotel")
        setLoading(false)
        return
      }

      if (!checkInDate || !checkOutDate) {
        setError("Please select both check-in and check-out dates")
        setLoading(false)
        return
      }

      const checkIn = new Date(checkInDate)
      const checkOut = new Date(checkOutDate)

      if (checkOut <= checkIn) {
        setError("Check-out date must be after check-in date")
        setLoading(false)
        return
      }

      const totalPrice = calculateTotalPrice()

      createBooking(
        user.id,
        hotelId,
        hotelName,
        checkInDate,
        checkOutDate,
        Number.parseInt(guests),
        roomType,
        totalPrice,
      )

      setSuccess(true)
      setTimeout(() => {
        setCheckInDate("")
        setCheckOutDate("")
        setGuests("1")
        setRoomType("standard")
        setSuccess(false)
        onBookingComplete?.()
      }, 2000)
    } finally {
      setLoading(false)
    }
  }

  return (
    <Card className="bg-slate-900/50 border-amber-900/20">
      <CardHeader>
        <CardTitle className="text-amber-100 font-serif">Book Your Stay</CardTitle>
        <CardDescription className="text-slate-400">{hotelName}</CardDescription>
      </CardHeader>
      <CardContent>
        {success && (
          <div className="mb-4 p-4 bg-green-950/30 border border-green-900/50 rounded-lg text-green-200 text-sm">
            <p className="font-semibold">Booking confirmed!</p>
            <p>Your reservation has been saved. Check your bookings for details.</p>
          </div>
        )}

        {error && (
          <div className="mb-4 flex gap-2 p-3 bg-red-950/30 border border-red-900/50 rounded-lg text-red-200 text-sm">
            <AlertCircle className="h-4 w-4 flex-shrink-0 mt-0.5" />
            <span>{error}</span>
          </div>
        )}

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm text-amber-200 flex items-center gap-2">
                <Calendar className="h-4 w-4" /> Check-in
              </label>
              <Input
                type="date"
                value={checkInDate}
                onChange={(e) => setCheckInDate(e.target.value)}
                className="bg-slate-800/50 border-amber-900/30 text-white"
              />
            </div>
            <div className="space-y-1">
              <label className="text-sm text-amber-200 flex items-center gap-2">
                <Calendar className="h-4 w-4" /> Check-out
              </label>
              <Input
                type="date"
                value={checkOutDate}
                onChange={(e) => setCheckOutDate(e.target.value)}
                className="bg-slate-800/50 border-amber-900/30 text-white"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm text-amber-200 flex items-center gap-2">
                <Users className="h-4 w-4" /> Guests
              </label>
              <Input
                type="number"
                min="1"
                max="10"
                value={guests}
                onChange={(e) => setGuests(e.target.value)}
                className="bg-slate-800/50 border-amber-900/30 text-white"
              />
            </div>
            <div className="space-y-1">
              <label className="text-sm text-amber-200">Room Type</label>
              <select
                value={roomType}
                onChange={(e) => setRoomType(e.target.value)}
                className="w-full px-3 py-2 bg-slate-800/50 border border-amber-900/30 text-white rounded-md text-sm"
              >
                <option value="standard">Standard ($)</option>
                <option value="deluxe">Deluxe (1.5x)</option>
                <option value="suite">Suite (2x)</option>
              </select>
            </div>
          </div>

          {checkInDate && checkOutDate && (
            <div className="p-3 bg-amber-950/30 border border-amber-900/30 rounded-lg">
              <div className="flex justify-between items-center">
                <span className="text-slate-300">Total Price:</span>
                <span className="text-xl font-serif font-bold text-amber-400">${calculateTotalPrice().toFixed(2)}</span>
              </div>
              <p className="text-xs text-slate-500 mt-1">Includes all taxes and fees</p>
            </div>
          )}

          <Button
            type="submit"
            disabled={loading || !checkInDate || !checkOutDate}
            className="w-full bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-500 hover:to-amber-600 text-white"
          >
            {loading ? "Processing..." : "Confirm Booking"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
